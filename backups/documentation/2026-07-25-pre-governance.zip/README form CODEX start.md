# ETABS Beam Project

## 项目概述
- **路径**: F:\2026\课题申报\etabs beam
- **素材**: eam gennerator.mp4 → 已提取12帧 (ideo_frames/frame_00_0s.png ~ rame_11_30s.png)
- **脚本**: xtract_frames.ps1, FrameExtractor.cs (C# 备选)
- **目标**: 基于视频素材进行 ETABS 梁结构建模与分析

## CSI API 资源

| 软件 | 文档 (chm) | DLL (x64) |
|------|-----------|-----------|
| ETABS 22 | E:\Program Files\Computers and Structures\ETABS 22\CSI API ETABS v1.chm | NativeAPI\x64\ETABSv1.dll |
| SAP2000 26 | E:\Program Files\Computers and Structures\SAP2000 26\CSI_OAPI_Documentation.chm | NativeAPI\x64\CSiAPIv1.dll |

API 调用: COM/OAPI，支持 C#/Python/MATLAB/VB。DLL 引用后创建对象启动软件。


## 任务记录
- [x] 提取视频内容
- [x] 识别 CSI API 文档位置 (ETABS 22, SAP2000 26)
